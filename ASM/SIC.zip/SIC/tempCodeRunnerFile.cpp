
            if(data[i].size() == 2){//fill the blank